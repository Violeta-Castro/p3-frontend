# P3 · Página que consume la API de productos

Página estática (HTML, CSS y JavaScript) publicada en GitHub Pages. Consume la API REST desplegada en Render: lista productos (GET público) y agrega, edita y elimina productos (POST, PUT y DELETE con el header `x-api-key`).

**Equipo:** Carmen Violeta Castro Trejo · Christopher Edwin Delgadillo Cerda
**Página:** https://USUARIO.github.io/p3-frontend/  ← reemplazar
**API:** https://TU-API.onrender.com/api/productos  ← reemplazar

## Archivos

| Archivo | Contenido |
|---|---|
| `index.html` | Formulario (nombre, precio, stock), mensaje de estado y contenedor de tarjetas |
| `app.js` | `listar()` hace GET; `peticionProtegida()` envía POST, PUT y DELETE con el token |
| `styles.css` | Estilos de la página |

## Configuración

En `app.js`, cambiar `API_URL` por la URL de Render del equipo y `API_KEY` por la misma clave configurada en Render.

## Probar en local

Abrir `index.html` con Live Server (puerto 5500). El origen `http://127.0.0.1:5500` debe estar en la variable `ORIGEN_PERMITIDO` de la API. Si se abre en otro puerto, por ejemplo 5501, la consola muestra un error de CORS: es la prueba de que la restricción funciona.

## Publicar

Settings › Pages › Deploy from a branch › `main` / `(root)` › Save. Después, agregar `https://USUARIO.github.io` a `ORIGEN_PERMITIDO` en Render (solo protocolo y dominio, sin ruta ni diagonal final).

## Limitación conocida

La clave escrita en `app.js` la puede ver cualquiera que abra el código fuente de la página. Sirve para aprender el mecanismo; en un sistema real el token se obtiene al iniciar sesión y caduca.
