// URL pública de la API en Render (cámbiala por la de tu equipo).
const API_URL = "https://TU-API.onrender.com/api/productos";
const API_KEY = "clave-del-equipo-cambiala"; // solo para la práctica: cualquiera puede verla

const formulario = document.getElementById("formProducto");
const btnGuardar = document.getElementById("btnGuardar");
const btnCancelar = document.getElementById("btnCancelar");
const mensaje = document.getElementById("mensaje");
const resultados = document.getElementById("resultados");

let productos = [];      // última lista recibida de la API
let idEditando = null;   // null = agregando; un número = editando ese producto

// Convierte texto en HTML seguro: si alguien guarda un nombre con etiquetas
// (<script>, <img onerror=...>) se muestra como texto y no se ejecuta.
function escapar(texto) {
  return String(texto)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// GET público: no necesita token.
async function listar() {
  mensaje.textContent = "Cargando... (si la API estaba dormida puede tardar cerca de un minuto)";
  try {
    const respuesta = await fetch(API_URL);
    if (!respuesta.ok) throw new Error(`código ${respuesta.status}`);
    productos = await respuesta.json();
    resultados.innerHTML = productos.map(p => `
      <article class="tarjeta">
        <h3>${escapar(p.nombre)}</h3>
        <p>Precio: $${escapar(p.precio)} · Stock: ${escapar(p.stock)}</p>
        <div class="acciones">
          <button data-accion="editar" data-id="${p.id}">Editar</button>
          <button data-accion="eliminar" data-id="${p.id}" class="peligro">Eliminar</button>
        </div>
      </article>`).join("");
    mensaje.textContent = `${productos.length} producto(s)`;
  } catch (error) {
    mensaje.textContent = "No se pudo conectar con la API: " + error.message;
  }
}

// POST, PUT y DELETE: llevan el header x-api-key que la API revisa.
async function peticionProtegida(url, metodo, datos) {
  const respuesta = await fetch(url, {
    method: metodo,
    headers: { "Content-Type": "application/json", "x-api-key": API_KEY },
    body: datos ? JSON.stringify(datos) : undefined
  });
  if (!respuesta.ok) {
    const error = await respuesta.json();
    throw new Error(error.errores ? error.errores.join(", ") : error.error);
  }
}

function salirDeEdicion() {
  idEditando = null;
  formulario.reset();
  btnGuardar.textContent = "Agregar";
  btnCancelar.hidden = true;
}

formulario.addEventListener("submit", async (e) => {
  e.preventDefault();
  const datos = {
    nombre: document.getElementById("txtNombre").value.trim(),
    precio: Number(document.getElementById("txtPrecio").value),
    stock: parseInt(document.getElementById("txtStock").value)
  };
  try {
    if (idEditando === null) {
      await peticionProtegida(API_URL, "POST", datos);              // crear
    } else {
      await peticionProtegida(`${API_URL}/${idEditando}`, "PUT", datos); // editar (reto)
    }
    salirDeEdicion();
    listar();
  } catch (error) {
    mensaje.textContent = "No se pudo guardar: " + error.message;
  }
});

btnCancelar.addEventListener("click", salirDeEdicion);

resultados.addEventListener("click", async (e) => {
  const boton = e.target.closest("button");
  if (!boton) return;
  const id = Number(boton.dataset.id);

  if (boton.dataset.accion === "editar") {
    const p = productos.find(prod => prod.id === id);
    if (!p) return;
    document.getElementById("txtNombre").value = p.nombre;
    document.getElementById("txtPrecio").value = p.precio;
    document.getElementById("txtStock").value = p.stock;
    idEditando = id;
    btnGuardar.textContent = "Guardar cambios";
    btnCancelar.hidden = false;
    document.getElementById("txtNombre").focus();
    return;
  }

  if (boton.dataset.accion === "eliminar") {
    try {
      await peticionProtegida(`${API_URL}/${id}`, "DELETE");
      if (idEditando === id) salirDeEdicion();
      listar();
    } catch (error) {
      mensaje.textContent = "No se pudo eliminar: " + error.message;
    }
  }
});

listar();
